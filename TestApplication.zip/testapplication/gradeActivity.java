package com.example.supi.testapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import java.util.ArrayList;

public class gradeActivity extends AppCompatActivity {
    Button btnAdd;
    Button btnSummary;
    EditText txtGrade;
    String stgrade = null;
    public static ArrayList <Double>listOfGrades = new ArrayList<Double>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade);
        btnAdd = findViewById(R.id.btnAdd);
        txtGrade = findViewById(R.id.grade);
        btnSummary = findViewById(R.id.btnsummary);
        btnAdd.setOnClickListener(new View.OnClickListener() {

                                      @Override
                                      public void onClick(View v) {
                                          stgrade = txtGrade.getText().toString();
                                          if (stgrade.isEmpty()) {
                                              Toast.makeText(gradeActivity.this, "Please enter a grade", Toast.LENGTH_LONG).show();
                                          } else if (listOfGrades.contains(Double.parseDouble(stgrade))) {
                                              Toast.makeText(gradeActivity.this, "This grade already exist", Toast.LENGTH_LONG).show();
                                          } else {
                                              listOfGrades.add(Double.parseDouble(stgrade));
                                              txtGrade.setText("");
                                          }
                                      }
                                  });

        btnSummary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(getApplicationContext(),summary_gradeActivity.class);
                startActivity(intent);
                Toast toast =Toast.makeText(getApplicationContext(),"This button has been clicked",Toast.LENGTH_LONG);
                        toast.show();
            }
        });
    }

}
